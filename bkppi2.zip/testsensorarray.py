import time
from sense_hat import AstroPi

ap = AstroPi()


while True:
    f = open("/home/pi/Desktop/readings.txt","a")
    localtime = str(time.asctime( time.localtime(time.time()) ))
    pressure = str(ap.get_pressure())
    humidity = str(ap.get_humidity())
    temp = str(ap.get_temperature())
    msg = localtime + " " + pressure + " " + humidity + " " + temp 
    print(msg)
    f.write(msg)
    f.write("\n")
    f.close()
    time.sleep(30)


