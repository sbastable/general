
git clone https://github.com/simonmonk/pi_starter_kit.git
echo "Renaming folder to rpesk"
mv pi_starter_kit rpesk
echo "Finished"