!/usr/bin/python
import time
#from sense_hat import SenseHat
from sense_hat import AstroPi

#sense = SenseHat()
ap = AstroPi()

msleep = lambda x: time.sleep(x / 1000.0)


while True:
    temp = ap.get_temperature()
    print(temp)
    temp2 = str(temp)
    ap.show_message (temp2)
    msleep(7000)



