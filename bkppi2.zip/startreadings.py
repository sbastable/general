import time
from sense_hat import AstroPi

ap = AstroPi()


while True:
    f = open("/home/pi/Desktop/readings.txt","a")
    localtime = str(time.asctime( time.localtime(time.time()) ))
    pressure = str(ap.get_pressure())
    humidity = str(ap.get_humidity())
    temp = str(ap.get_temperature())
    temp2 = str(ap.get_temperature_from_humidity())
    temp3 = str(ap.get_temperature_from_pressure())
    print(localtime, pressure, humidity, temp, temp2, temp3)
    f.write(localtime + " " + pressure + " " + humidity + " " + temp + " " + temp2 + " " +temp3 + "\n")
    f.close()
    time.sleep(10)

