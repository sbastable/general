#!/usr/bin/python
import time
from sense_hat import SenseHat

sense = SenseHat()

r = 0
g = 0
b = 0
sense.clear([r, g, b])
